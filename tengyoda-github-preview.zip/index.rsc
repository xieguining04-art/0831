2:I["8c0f216c4604",[],"Children",1]
3:I["044ce6af781f",[],"SiteAnalytics",1]
4:I["15c18cfaeeff",[],"LayoutSegmentProvider",1]
5:I["8c0f216c4604",[],"Slot",1]
6:I["593f344dc510",[],"RedirectBoundary",1]
:HL["/0831/assets/index-BpVikkW9.css","style"]
0:{"__route":"route:/","__interceptionContext":null,"__layoutIds":["layout:/"],"__rootLayout":"/","page:/":"$L1","layout:/":[[[["$","link","css:/0831/assets/index-BpVikkW9.css",{"rel":"stylesheet","precedence":"vite-rsc/importer-resources","href":"/0831/assets/index-BpVikkW9.css","data-rsc-css-href":"/0831/assets/index-BpVikkW9.css"}],"$undefined"],["$","html",null,{"lang":"en","children":["$","body",null,{"className":"antialiased","children":[["$","$L2",null,{}],["$","$L3",null,{}]]}]}]],null],"route:/":[[["$","meta",null,{"charSet":"utf-8"}],[["$","title","0",{"children":"China Freight Forwarder | Global Sea Freight | TengYoda"}],["$","meta","1",{"name":"description","content":"Global sea freight booking from China, focused on Oceania, Africa and South America. Plan FCL and LCL shipping with pickup and consolidation support."}],["$","meta","2",{"name":"robots","content":"noindex, follow"}],["$","link","3",{"rel":"shortcut icon","href":"/0831/favicon.svg?v=tengyoda-2"}],["$","link","4",{"rel":"icon","href":"/0831/favicon.svg?v=tengyoda-2"}],["$","link","5",{"rel":"canonical","href":"https://tengyodalogistics.com/"}]],[["$","meta","0",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]],["$","$L4",null,{"segmentMap":{"children":[]},"children":["$","$L5",null,{"id":"layout:/","parallelSlots":"$undefined","children":["$","$L6",null,{"children":["$","$L4",null,{"segmentMap":{"children":[]},"children":["$","$L5",null,{"id":"page:/"}]}]}]}]}]],"__layoutFlags":{"layout:/":"s"},"__artifactCompatibility":{"schemaVersion":1,"graphVersion":"app-route-graph:4uhn5s1wvoptc","deploymentVersion":"985ea5e5-384e-403c-8d4f-c590090777b6","appElementsSchemaVersion":1,"rscPayloadSchemaVersion":1,"rootBoundaryId":"/","renderEpoch":null}}
7:I["6efdf509a785",[],"default",1]
1:["$","$L7",null,{"params":"$@8","searchParams":"$@9"}]
8:{}
9:{}
